from zpqc.core import PostQuantumModule

def test_encrypt_decrypt():
    pqm = PostQuantumModule()
    msg = "secret"
    enc = pqm.encrypt(msg)
    dec = pqm.decrypt(enc)
    assert "fictif" in enc and "fictif" in dec
