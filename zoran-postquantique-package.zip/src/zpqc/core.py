class PostQuantumModule:
    def __init__(self):
        pass

    def encrypt(self, message):
        return f"Message chiffré (fictif) : {message}"

    def decrypt(self, encrypted_message):
        return f"Message déchiffré (fictif) : {encrypted_message}"

    def sign(self, data):
        return f"Signature (fictive) de : {data}"

    def verify(self, data, signature):
        return f"Vérification (fictive) de la signature {signature} pour : {data}"
