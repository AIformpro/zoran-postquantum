from zpqc.core import PostQuantumModule

pqm = PostQuantumModule()
print(pqm.encrypt("message test"))
print(pqm.decrypt("message chiffré test"))
print(pqm.sign("artefact QG"))
print(pqm.verify("artefact QG", "signature"))
